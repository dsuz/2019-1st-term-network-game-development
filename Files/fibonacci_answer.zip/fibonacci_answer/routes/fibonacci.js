﻿'use strict';
var express = require('express');
var router = express.Router();

/* GET リクエストの処理 */
router.get('/', function (req, res) {
    var values = {
        message: ''
    };

    res.render('fibonacci', values);    // values を渡しながら ejs を使ってページを生成する
});

/* POST リクエスト（データが送られてきた時）の処理 */
router.post('/', function (req, res) {
    var n = req.body['number']; // 送られてきたデータを受信する

    // フィボナッチ数を求め、メッセージとして渡す
    var strMessage = n + ' 番目のフィボナッチ数は ' + fibonacci(n) + ' です';

    // html を生成する
    var values = {
        message: strMessage
    };

    res.render('fibonacci', values);    // values を渡しながら ejs を使ってページを生成する
});

// n 番目のフィボナッチ数を求める
function fibonacci(n) {
    if (n == 1 || n == 2) {
        return 1;
    } else {
        return fibonacci(n - 2) + fibonacci(n - 1);
    }
}

module.exports = router;    // 他のコードから参照できるようにするための命令
