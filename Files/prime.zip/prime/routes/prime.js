﻿'use strict';
var express = require('express');
var router = express.Router();

/* GET リクエストの処理 */
router.get('/', function (req, res) {
    var values = {
        message: ''
    };

    res.render('prime', values);    // values を渡しながら ejs を使ってページを生成する
});

/* POST リクエスト（データが送られてきた時）の処理 */
router.post('/', function (req, res) {
    var n = req.body['number']; // 送られてきたデータを受信する

    // 素数の判定結果によって異なるメッセージを作る
    var strMessage = '';
    if (isPrime(n)) {
        strMessage = n + ' は素数です';
    } else {
        strMessage = n + ' は素数ではありません';
    }

    // html を生成する
    var values = {
        message: strMessage
    };

    res.render('prime', values);    // values を渡しながら ejs を使ってページを生成する
});

// n の素数判定をする。n が素数なら true、素数でない場合は false を返す
function isPrime(n) {
    // 1 は素数ではない
    if (n == 1) {
        return false;
    }

    // 2 は素数
    if (n == 2) {
        return true;
    }

    // 3 以上の時は、割り算をして素数か判定する
    for (var i = 2; i < n; i++) {
        if (n % i == 0) {
            return false;
        }
    }

    return true;
}

module.exports = router;    // 他のコードから参照できるようにするための命令
