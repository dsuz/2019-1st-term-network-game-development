﻿'use strict';
var express = require('express');
var router = express.Router();

// データベース接続設定
const pg = require('pg');
const connectionString = process.env.DATABASE_URL;  //(プロジェクトプロパティの)環境変数からデータベース接続文字列を取得する
const pool = new pg.Pool({
    connectionString: connectionString
});

// GET リクエストを受け取った時の処理（データベースからメッセージを取ってきて表示する）
router.get('/', function (req, res) {
    const q = 'SELECT * FROM messages ORDER BY timestamp DESC LIMIT 10'; // クエリ（新しいものから 10 件データを取ってくる）
    pool.query(q, (err, result) => {    // クエリを発行する
        if (err) {  // エラーの時
            console.log(err.stack); // 標準出力にスタックトレースを出力する
        } else {    // 正常に結果が取得できた時
            var values = { messages: result.rows }; // 取得できたデータをまとめて
            res.render('index', values);    // テンプレートに渡す
        }
    });
});

// POST リクエストを受け取った時の処理
router.post('/', function (req, res) {
    const message = req.body['message'];    // POST されてきたデータを取り出す
    const insertSql = 'INSERT INTO messages VALUES((SELECT COALESCE(Max(id), 0) FROM messages) + 1, \'' + message + '\', now())';   // SQL 文を作る
    console.log('execute: ' + insertSql);   // これから実行する SQL 文をデバッグ出力する

    // SQL 文を実行する
    pool.query(insertSql, (err, result) => {    
        if (err) {  // エラーの時
            console.log(err.stack);
        } else {    // 正常に実行できた時
            res.redirect('.');  // 同じページにリダイレクトする
        }
    });
});

module.exports = router;
