﻿'use strict';
var express = require('express');
var router = express.Router();

const pg = require('pg');
const connectionString = process.env.DATABASE_URL;  //(プロジェクトプロパティの)環境変数からデータベース接続文字列を取得する
const pool = new pg.Pool({
    connectionString: connectionString
});

/* GET users listing. */
router.get('/', function (req, res) {
    const id = req.query.id;
    const deleteSql = 'DELETE FROM messages WHERE id = ' + id;
    console.log('deleteSql: ' + deleteSql);

    pool.query(deleteSql, (err, result) => {    // クエリを実行する
        if (err) {  // エラーの時
            console.log(err.stack);
        } else {    // 正常に結果が取得できた時
            res.redirect('/');  // トップページにリダイレクトする
        }
    });
});

module.exports = router;
